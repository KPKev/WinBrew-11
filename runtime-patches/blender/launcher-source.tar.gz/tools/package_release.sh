#!/bin/sh
# SPDX-License-Identifier: LGPL-2.1-or-later
#
# The app folder a player uploads to /data/homebrew: the title from
# tools/build_native.sh with its Wine runtime beside it, under win/wine.
#
#   PPSA99995/
#     eboot.bin, sce_sys/, sce_module/          the title (no dev.conf)
#     win/wine/lib/wine/i386-windows/           Wine's PE modules
#     win/wine/lib/wine/x86_64-windows/
#     win/wine/lib/wine/x86_64-unix/*.prx       Wine's PS5 side
#     win/wine/share/wine/nls/, fonts/
#     win/mesa-zink/{i386,x86_64}-windows/      Mesa WGL/Zink: OpenGL
#     LICENSE, THIRD_PARTY.md, LICENSES/       the licences of everything above
#     SOURCES.txt                               the source revision of each part
#
# Where each part comes from:
#   --title DIR      tools/build_native.sh's dist/PPSA99995. Its dev.conf,
#                    which names the builder's PC, is left out.
#   --wine-ps5 DIR   tools/build_wine_ps5.sh's work directory
#                    (.deps/wine-ps5): prx/sce_module/*.prx, prx/fonts/,
#                    the PE modules its patches change (pe/), report.json
#                    for the revisions behind them, and the Wine and
#                    FreeType sources it built, for their licence files.
#   --host-wine DIR  tools/build_host_wine.sh's installation (its usr/): the
#                    same revision and patches, whose PE modules and NLS
#                    files the console runs. Import libraries and the
#                    drivers that need the PC's own libraries are left out.
#   --cpu-dll FILE   tools/build_wowprospero.sh's
#                    x86_64-windows/wowprospero.dll.
#   --native-cpu DIR tools/build_wow64native.sh's --output with the PS5
#                    inputs: x86_64-windows/wow64native.dll and
#                    ps5/wow64native.prx, the native WoW64 CPU that 32-bit
#                    games run on by default.
#   --lapy-release FILE  the release.json tools/build_native.sh saved for the
#                    lapy.elf it fetched (build/native/lapy-helper-release.json);
#                    required unless --helper-elf names a local helper.
#   --mesa-zink DIR  tools/build_mesa_zink.sh's artifacts/ directory:
#                    PE32/PE64 WGL/Zink, hashes and component licence texts.
#                    OpenGL games draw through it (graphics = opengl).
#   --title-id ID    output title identity (default PW_TITLE_ID or PPSA99995).
#   --helper-elf FILE and --helper-manifest FILE provide the matching pinned
#                    helper pair; they are required for non-default titles.
#   --out DIR        where TITLE_ID/ is written (replaced).
#   --zip            also write DIR/TITLE_ID.zip.
#
# A game's prefix gets its own copy of wowprospero.dll from
# tools/pw_prefix.py push --cpu-dll.
set -eu

root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
mesa_zink= title= wine_ps5= host_wine= cpu_dll= native_cpu= lapy_release= out= zip=0
title_id=${PW_TITLE_ID:-PPSA99995}
helper_elf=${PW_LAPY_HELPER_ELF:-}
helper_manifest=${PW_LAPY_HELPER_MANIFEST:-}
fail() { echo "package_release: $*" >&2; exit 2; }
while [ $# -gt 0 ]; do
    case $1 in
    --mesa-zink) mesa_zink=$2; shift 2 ;;
    --title) title=$2; shift 2 ;;
    --wine-ps5) wine_ps5=$2; shift 2 ;;
    --host-wine) host_wine=$2; shift 2 ;;
    --cpu-dll) cpu_dll=$2; shift 2 ;;
    --native-cpu) native_cpu=$2; shift 2 ;;
    --lapy-release) lapy_release=$2; shift 2 ;;
    --out) out=$2; shift 2 ;;
    --title-id) title_id=$2; shift 2 ;;
    --helper-elf) helper_elf=$2; shift 2 ;;
    --helper-manifest) helper_manifest=$2; shift 2 ;;
    --zip) zip=1; shift ;;
    *) fail "unknown argument $1" ;;
    esac
done
printf '%s\n' "$title_id" | grep -Eq '^[A-Z]{4}[0-9]{5}$' ||
    fail "--title-id must be four uppercase letters followed by five digits"
[ -z "$helper_elf" ] && [ -z "$helper_manifest" ] ||
    { [ -n "$helper_elf" ] && [ -n "$helper_manifest" ]; } ||
    fail "--helper-elf and --helper-manifest must be set together"
if [ "$title_id" != PPSA99995 ] && [ -z "$helper_elf" ]; then
    fail "per-game --title-id $title_id requires --helper-elf and --helper-manifest"
fi
if [ -n "$helper_elf" ]; then
    [ -f "$helper_elf" ] || fail "--helper-elf: no file '$helper_elf'"
    [ -f "$helper_manifest" ] || fail "--helper-manifest: no file '$helper_manifest'"
    if ! python3 - "$root" "$helper_elf" "$helper_manifest" "$title_id" \
        "$root/native/lapy_elevation_protocol.h" <<'PY'
import json, pathlib, sys
sys.path.insert(0, sys.argv[1])
from tools.fetch_lapy_helper import validate_helper_manifest
try:
    validate_helper_manifest(json.loads(pathlib.Path(sys.argv[3]).read_text()),
                             pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[5]),
                             sys.argv[4])
except (OSError, ValueError, json.JSONDecodeError) as error:
    raise SystemExit(str(error))
PY
    then
        exit 2
    fi
fi
[ -f "$title/eboot.bin" ] && [ -d "$title/sce_sys" ] || fail "--title: no eboot.bin and sce_sys/ in '$title'"
[ -f "$title/lapy.elf" ] || fail "--title: no lapy.elf in '$title'"
native_build_manifest=$title/native-title-build.json
if [ "$title_id" != PPSA99995 ] && [ ! -f "$native_build_manifest" ]; then
    fail "--title: no native-title-build.json for per-game title '$title_id'"
fi
if [ -f "$native_build_manifest" ]; then
    if ! python3 - "$native_build_manifest" "$title/eboot.bin" "$title_id" <<'PY'
import hashlib, json, pathlib, re, sys
manifest_path, eboot_path, title_id = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
try:
    manifest = json.loads(manifest_path.read_text())
except (OSError, json.JSONDecodeError) as error:
    raise SystemExit(f"invalid native-title-build.json: {error}")
if manifest.get("schema") != "prospero-win-native-title/1":
    raise SystemExit("native-title-build.json has unsupported schema")
if manifest.get("title_id") != title_id:
    raise SystemExit(
        f"compiled title {manifest.get('title_id')!r} does not match requested {title_id}")
revision = manifest.get("source_revision")
if not isinstance(revision, str) or not re.fullmatch(r"(?:[0-9a-f]{40}|unknown)", revision):
    raise SystemExit("native-title-build.json has invalid source_revision")
if not isinstance(manifest.get("source_dirty"), bool):
    raise SystemExit("native-title-build.json has invalid source_dirty")
recorded = manifest.get("eboot_sha256")
actual = hashlib.sha256(eboot_path.read_bytes()).hexdigest()
if not isinstance(recorded, str) or not re.fullmatch(r"[0-9a-f]{64}", recorded) or recorded != actual:
    raise SystemExit("native-title-build.json eboot digest does not match eboot.bin")
PY
    then
        exit 2
    fi
fi
if ! python3 - "$title/sce_sys/param.json" "$title_id" <<'PY'
import json, pathlib, sys
try:
    actual = json.loads(pathlib.Path(sys.argv[1]).read_text()).get("titleId")
except (OSError, json.JSONDecodeError) as error:
    raise SystemExit(f"invalid title param.json: {error}")
if actual != sys.argv[2]:
    raise SystemExit(f"param.json titleId {actual!r} does not match {sys.argv[2]}")
PY
then
    exit 2
fi
ls "$wine_ps5"/prx/sce_module/ntdll.prx >/dev/null 2>&1 || fail "--wine-ps5: no prx/sce_module/ntdll.prx in '$wine_ps5'"
[ -d "$wine_ps5/prx/fonts" ] || fail "--wine-ps5: no prx/fonts in '$wine_ps5'"
[ -d "$host_wine/lib/wine/i386-windows" ] && [ -d "$host_wine/lib/wine/x86_64-windows" ] &&
    [ -d "$host_wine/share/wine/nls" ] || fail "--host-wine: '$host_wine' is not a WoW64 Wine installation (usr/)"
[ -f "$cpu_dll" ] || fail "--cpu-dll: no file '$cpu_dll'"
[ -f "$native_cpu/x86_64-windows/wow64native.dll" ] && [ -f "$native_cpu/ps5/wow64native.prx" ] ||
    fail "--native-cpu: no x86_64-windows/wow64native.dll and ps5/wow64native.prx in '$native_cpu'"
if [ -z "$helper_elf" ] || [ -n "$lapy_release" ]; then
    [ -f "$lapy_release" ] || fail "--lapy-release: no file '$lapy_release'"
fi
[ -f "$wine_ps5/report.json" ] || fail "--wine-ps5: no report.json in '$wine_ps5'"
for file in LICENSE COPYING.LIB AUTHORS NOTICES.md; do
    [ -f "$wine_ps5/source/$file" ] || fail "--wine-ps5: no Wine source/$file in '$wine_ps5'"
done
[ -f "$wine_ps5/freetype/src/docs/FTL.TXT" ] ||
    fail "--wine-ps5: no FreeType source (freetype/src/docs/FTL.TXT) in '$wine_ps5'"
# A PS5 build with schannel (tools/build_tls_ps5.sh) carries the root
# certificates and the licence texts of what libgnutls.prx links.
tls=0
if [ -f "$wine_ps5/prx/sce_module/libgnutls.prx" ]; then
    tls=1
    [ -f "$wine_ps5/prx/ca-certificates.crt" ] ||
        fail "--wine-ps5: libgnutls.prx without prx/ca-certificates.crt in '$wine_ps5'"
    for file in gnutls/COPYING.LESSERv2 nettle/COPYING.LESSERv3; do
        [ -f "$wine_ps5/prx/licenses/$file" ] ||
            fail "--wine-ps5: libgnutls.prx without prx/licenses/$file in '$wine_ps5'"
    done
fi
[ -n "$out" ] || fail "--out DIR is required"
[ -n "$mesa_zink" ] || fail "--mesa-zink DIR is required: OpenGL games draw through Zink"
python3 "$root/tools/package_mesa_zink.py" "$mesa_zink" || fail "--mesa-zink: invalid artifact directory '$mesa_zink'"

app=$out/$title_id
rm -rf "$app"
mkdir -p "$app"
# The title, without the builder's log destination.
( cd "$title" && find . -type f ! -name dev.conf ) | while read -r file; do
    mkdir -p "$app/$(dirname "$file")"
    cp "$title/$file" "$app/$file"
done
if [ -n "$helper_elf" ]; then
    cp "$helper_elf" "$app/lapy.elf"
    cp "$helper_manifest" "$app/lapy-manifest.json"
fi

lib=$app/win/wine/lib/wine
share=$app/win/wine/share/wine
mkdir -p "$lib/x86_64-unix" "$share/nls" "$share/fonts"
for arch in i386-windows x86_64-windows; do
    mkdir -p "$lib/$arch"
    for file in "$host_wine/lib/wine/$arch"/*; do
        name=${file##*/}
        case $name in
        # Import libraries, and what needs the PC's own libraries: X11,
        # GStreamer, pcap, SANE and libgphoto2.
        *.a|winex11.drv|winegstreamer.dll|wpcap.dll|sane.ds|gphoto2.ds) continue ;;
        esac
        cp "$file" "$lib/$arch/$name"
    done
    # The PE modules the PS5 patches change (PE_MODULES in build_wine_ps5.sh).
    if [ -d "$wine_ps5/pe/$arch" ]; then cp "$wine_ps5/pe/$arch"/*.dll "$lib/$arch/"; fi
done
cp "$cpu_dll" "$lib/x86_64-windows/wowprospero.dll"
# The native WoW64 CPU: the launcher copies the DLL into a game's prefix.
cp "$native_cpu/x86_64-windows/wow64native.dll" "$lib/x86_64-windows/wow64native.dll"
cp "$native_cpu/ps5/wow64native.prx" "$lib/x86_64-unix/wow64native.prx"
cp "$wine_ps5"/prx/sce_module/*.prx "$lib/x86_64-unix/"
cp "$host_wine"/share/wine/nls/* "$share/nls/"
cp "$wine_ps5"/prx/fonts/* "$share/fonts/"
# The PS5 kernel refuses to exec an eboot without execute permission and its
# loader refuses a PRX without it, so every executable module is 0755.
chmod 755 "$app/eboot.bin"
find "$app" -type f -name '*.prx' -exec chmod 755 {} +
# The root certificates crypt32 reads on the console (patch 0878), when
# the PS5 build has schannel.
if [ "$tls" = 1 ]; then cp "$wine_ps5/prx/ca-certificates.crt" "$share/"; fi

# The licences (THIRD_PARTY.md says which covers what): the project's own
# texts, then Wine's, FreeType's and, with schannel, GnuTLS's and nettle's
# from the sources that were built.
cp "$root/LICENSE" "$root/THIRD_PARTY.md" "$app/"
cp -R "$root/LICENSES" "$app/LICENSES"
mkdir -p "$app/LICENSES/wine/libs" "$app/LICENSES/freetype"
for file in LICENSE COPYING.LIB AUTHORS NOTICES.md; do cp "$wine_ps5/source/$file" "$app/LICENSES/wine/"; done
for file in "$wine_ps5"/source/libs/*/LICENSE* "$wine_ps5"/source/libs/*/COPYING* \
    "$wine_ps5"/source/libs/*/COPYRIGHT*; do
    [ -f "$file" ] || continue
    library=$(basename "$(dirname "$file")")
    mkdir -p "$app/LICENSES/wine/libs/$library"
    cp "$file" "$app/LICENSES/wine/libs/$library/"
done
cp "$wine_ps5/freetype/src/LICENSE.TXT" "$wine_ps5/freetype/src/docs/FTL.TXT" "$app/LICENSES/freetype/"
if [ "$tls" = 1 ]; then
    cp -R "$wine_ps5/prx/licenses/gnutls" "$app/LICENSES/gnutls"
    cp -R "$wine_ps5/prx/licenses/nettle" "$app/LICENSES/nettle"
fi

# SOURCES.txt: the revision of each part, from the build's own records.
# A local helper (--helper-elf) has no release record; its manifest names it.
python3 - "$root" "$wine_ps5/report.json" "$lapy_release" "$app" "$helper_manifest" <<'PY' || exit 2
import hashlib, json, re, subprocess, sys
from pathlib import Path
root, report, app = Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text()), Path(sys.argv[4])
lapy = json.loads(Path(sys.argv[3]).read_text()) if sys.argv[3] else {}
helper = json.loads(Path(sys.argv[5]).read_text()) if sys.argv[5] else None
def pin(script, name):
    return re.search(rf"^{name}=(\S+)$", (root / "tools" / script).read_text(), re.M).group(1)
def fail(message):
    sys.exit(f"package_release: {message}")
git = lambda *args: subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True).stdout.strip()
sources = report.get("sources") or {}
if not report.get("wine_commit"):
    fail("--wine-ps5: report.json names no Wine commit")
if helper is None and not lapy.get("tag_name"):
    fail("--lapy-release: no tag_name")
vulkan = (app / "win/wine/lib/wine/x86_64-unix/libvulkan.prx").exists()
if vulkan and not sources.get("ps5_mesa"):
    fail("libvulkan.prx is not a RADV build in report.json; THIRD_PARTY.md covers RADV only")
commit = (git("rev-parse", "HEAD") or "not recorded") + \
    (" (with uncommitted changes)" if git("status", "--porcelain") else "")
lines = [
    "Source for this package. THIRD_PARTY.md says what each part is and its licence.",
    "",
    f"prospero-win  https://github.com/mpereiraesaa/prospero-win  commit {commit}",
    f"Wine  https://gitlab.winehq.org/wine/wine  commit {report['wine_commit']},",
    f"  with prospero-win's wine/patches ({len(report.get('patches', []))} patches)",
    "PS5 Native App Boilerplate  https://github.com/mpereiraesaa/ps5-native-app-boilerplate",
    f"  title: commit {pin('build_native.sh', 'pin')}",
    f"  PS5 module tools: commit {sources.get('prx_foundation') or 'not recorded'}",
    "PS5 payload SDK  https://github.com/ps5-payload-dev/sdk  the release the boilerplate pins",
    f"FreeType {pin('build_wine_ps5.sh', 'FREETYPE_VERSION')}  "
    f"{pin('build_wine_ps5.sh', 'FREETYPE_URL').replace('$FREETYPE_VERSION', pin('build_wine_ps5.sh', 'FREETYPE_VERSION'))}",
    f"  SHA-256 {pin('build_wine_ps5.sh', 'FREETYPE_SHA256')}",
    f"Lapy JB Daemon (lapy.elf)  {lapy.get('release_url') or 'https://github.com/mpereiraesaa/PS5-Lapy-JB-Daemon'}"
    + (f"  release {lapy['tag_name']}" if helper is None else
       f"  {helper.get('mode')} for {helper.get('target_title')}, lapy.elf SHA-256 {helper.get('elf_sha256')}"),
]
if vulkan:
    lines += [f"RADV (libvulkan.prx)  https://github.com/mpereiraesaa/PS5_Mesa  commit {sources['ps5_mesa']}",
              f"  linked by https://github.com/mpereiraesaa/PS5_Vulkan  commit {sources.get('ps5_vulkan') or 'not recorded'}",
              "  with the payload SDK and platform layer  https://github.com/mihawk-99/PS5_PayloadSDK"
              f"  commit {sources.get('radv_payload_sdk') or 'not recorded'}"]
# schannel: the libraries libgnutls.prx links and the root certificates,
# as tools/build_tls_ps5.sh pins them; the bundle staged is the pinned one
# unless the build named another (PROSPERO_CA_BUNDLE), in which case only
# its SHA-256 is known.
bundle = app / "win/wine/share/wine/ca-certificates.crt"
if (app / "win/wine/lib/wine/x86_64-unix/libgnutls.prx").exists():
    tls = "build_tls_ps5.sh"
    staged = hashlib.sha256(bundle.read_bytes()).hexdigest()
    pinned = pin(tls, "CA_BUNDLE_SHA256")
    date = pin(tls, "CA_BUNDLE_DATE")
    for name, url in (("GnuTLS", "GNUTLS_URL"), ("nettle", "NETTLE_URL")):
        version = pin(tls, f"{name.upper()}_VERSION")
        lines += [f"{name} {version} (libgnutls.prx)  "
                  f"{pin(tls, url).replace(f'${name.upper()}_VERSION', version)}",
                  f"  SHA-256 {pin(tls, f'{name.upper()}_SHA256')}"]
    if staged == pinned:
        lines += [f"Root certificates (share/wine/ca-certificates.crt)  "
                  f"{pin(tls, 'CA_BUNDLE_URL').replace('$CA_BUNDLE_DATE', date)}",
                  f"  SHA-256 {staged}"]
    else:
        lines += ["Root certificates (share/wine/ca-certificates.crt)  the builder's own bundle,"
                  f" not curl's cacert-{date}.pem", f"  SHA-256 {staged}"]
else:
    lines += ["schannel (GnuTLS, nettle, root certificates)  not included"]
(app / "SOURCES.txt").write_text("\n".join(lines) + "\n")
PY

python3 "$root/tools/package_mesa_zink.py" "$mesa_zink" --app "$app" || fail 'Mesa packaging failed'


files=$(find "$app" -type f | wc -l)
size=$(du -sh "$app" | cut -f1)
echo "package_release: $app: $files files, $size"
if [ "$zip" = 1 ]; then
    rm -f "$out/$title_id.zip"
    ( cd "$out" && zip -qr "$title_id.zip" "$title_id" )
    echo "package_release: $out/$title_id.zip"
fi
