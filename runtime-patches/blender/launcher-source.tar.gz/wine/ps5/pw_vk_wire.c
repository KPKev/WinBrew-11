/* SPDX-License-Identifier: LGPL-2.1-or-later */
#include "pw_vk_wire.h"
#include <string.h>
#include <limits.h>
#define MAX_PAYLOAD (1024u*1024u)
static void w32(void *v,uint32_t x){unsigned char *p=v;unsigned i;for(i=0;i<4;i++)p[i]=(unsigned char)(x>>(8*i));}
static void w64(void *v,uint64_t x){unsigned char *p=v;unsigned i;for(i=0;i<8;i++)p[i]=(unsigned char)(x>>(8*i));}
uint32_t pw_vk_wire_u32(const void *v){const unsigned char *p=v;uint32_t x=0;unsigned i;for(i=0;i<4;i++)x|=(uint32_t)p[i]<<(8*i);return x;}
uint64_t pw_vk_wire_u64(const void *v){const unsigned char *p=v;uint64_t x=0;unsigned i;for(i=0;i<8;i++)x|=(uint64_t)p[i]<<(8*i);return x;}
static int overlap(const void *a,size_t an,const void *b,size_t bn){uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;if(!an||!bn)return 0;return x<=y?y-x<an:x-y<bn;}
static int room(void *p,size_t cap,size_t n,size_t *out){if(!p||!out||n>cap||n>MAX_PAYLOAD||overlap(p,n,out,sizeof(*out)))return 0;memset(p,0,n);*out=n;return 1;}
int pw_vk_wire_draw(void *v,size_t cap,uint32_t cb,uint32_t n,uint32_t instances,uint32_t first,int32_t bias,uint32_t base,size_t *out){unsigned char *p=v;if(!room(v,cap,24,out))return 0;w32(p,cb);w32(p+4,n);w32(p+8,instances);w32(p+12,first);w32(p+16,(uint32_t)bias);w32(p+20,base);return 1;}
int pw_vk_wire_pipeline(void *v,size_t cap,uint32_t cb,uint32_t bind,uint64_t pipeline,size_t *out){unsigned char *p=v;if(!room(v,cap,16,out))return 0;w32(p,cb);w32(p+4,bind);w64(p+8,pipeline);return 1;}
int pw_vk_wire_index(void *v,size_t cap,uint32_t cb,uint64_t buffer,uint64_t offset,uint64_t size,uint32_t type,uint32_t sized,size_t *out){unsigned char *p=v;if(sized>1||!room(v,cap,40,out))return 0;w32(p,cb);w32(p+4,type);w64(p+8,buffer);w64(p+16,offset);w64(p+24,size);w32(p+32,sized);return 1;}
int pw_vk_wire_descriptors(void *v,size_t cap,uint32_t cb,uint32_t bind,uint64_t layout,uint32_t first,uint32_t count,const uint64_t *sets,uint32_t dc,const uint32_t *dynamic,size_t *out){unsigned char *p=v;size_t n=32,i;if(count>(MAX_PAYLOAD-n)/8)return 0;n+=(size_t)count*8;if(dc>(MAX_PAYLOAD-n)/4||(!sets&&count)||(!dynamic&&dc))return 0;n+=(size_t)dc*4;if(overlap(v,n,sets,(size_t)count*8)||overlap(v,n,dynamic,(size_t)dc*4))return 0;if(!room(v,cap,n,out))return 0;w32(p,cb);w32(p+4,bind);w64(p+8,layout);w32(p+16,first);w32(p+20,count);w32(p+24,dc);for(i=0;i<count;i++)w64(p+32+i*8,sets[i]);for(i=0;i<dc;i++)w32(p+32+(size_t)count*8+i*4,dynamic[i]);return 1;}
int pw_vk_wire_vertex2(void *v,size_t cap,uint32_t cb,uint32_t first,uint32_t count,const uint64_t *buffers,const uint64_t *offsets,const uint64_t *sizes,const uint64_t *strides,size_t *out){unsigned char *p=v;size_t n,i;if(count>(MAX_PAYLOAD-16)/32||(!buffers&&count)||(!offsets&&count))return 0;n=16+(size_t)count*32;if(overlap(v,n,buffers,(size_t)count*8)||overlap(v,n,offsets,(size_t)count*8)||(sizes&&overlap(v,n,sizes,(size_t)count*8))||(strides&&overlap(v,n,strides,(size_t)count*8)))return 0;if(!room(v,cap,n,out))return 0;w32(p,cb);w32(p+4,first);w32(p+8,count);w32(p+12,(sizes?1u:0u)|(strides?2u:0u));for(i=0;i<count;i++){w64(p+16+i*32,buffers[i]);w64(p+24+i*32,offsets[i]);if(sizes)w64(p+32+i*32,sizes[i]);if(strides)w64(p+40+i*32,strides[i]);}return 1;}
int pw_vk_wire_push_constants(void *wire, size_t capacity, uint32_t command_buffer,
                              uint64_t layout, uint32_t stages, uint32_t offset,
                              uint32_t bytes, const void *values, size_t *written)
{
    unsigned char *data = wire;
    size_t total;
    if (bytes > MAX_PAYLOAD - 24 || (bytes && !values) ||
        (bytes && (uintptr_t)values > UINTPTR_MAX - bytes)) return 0;
    total = 24 + (size_t)bytes;
    if (overlap(wire, total, values, bytes) || !room(wire, capacity, total, written)) return 0;
    w32(data, command_buffer); w32(data + 4, stages); w64(data + 8, layout);
    w32(data + 16, offset); w32(data + 20, bytes);
    if (bytes) memcpy(data + 24, values, bytes);
    return 1;
}
static unsigned elem(uint32_t type){if(type<=3||type==10)return 24;if(type==4||type==5)return 8;if(type>=6&&type<=9)return 24;if(type==1000138000)return 1;if(type==1000150000||type==1000165000)return 8;return 0;}
int pw_vk_template_extent(const struct pw_vk_template_entry *entries,size_t count,size_t *out){uint64_t span=0,last,stride;size_t i;unsigned unit;if(!out||(!entries&&count)||count>MAX_PAYLOAD/sizeof(*entries))return 0;for(i=0;i<count;i++){unit=elem(entries[i].type);if(!unit)return 0;if(entries[i].count>MAX_PAYLOAD/unit)return 0;if(!entries[i].count)continue;if(entries[i].offset>MAX_PAYLOAD||(entries[i].type!=1000138000&&entries[i].stride>MAX_PAYLOAD))return 0;stride=entries[i].type==1000138000?1:entries[i].stride;last=entries[i].offset+(uint64_t)(entries[i].count-1)*stride+unit;if(last>MAX_PAYLOAD-32)return 0;if(last>span)span=last;}*out=(size_t)span;return 1;}
int pw_vk_wire_template(void *v,size_t cap,uint32_t device,uint64_t set,uint64_t handle,const struct pw_vk_template_entry *entries,size_t count,const void *data,size_t *out){unsigned char *p=v;const unsigned char *src=data;size_t span,i,j;unsigned unit;if(!pw_vk_template_extent(entries,count,&span)||(!data&&span)||(span&&(uintptr_t)data>UINTPTR_MAX-span)||overlap(v,32+span,data,span)||overlap(v,32+span,entries,count*sizeof(*entries))||!room(v,cap,32+span,out))return 0;w32(p,device);w64(p+8,set);w64(p+16,handle);w32(p+24,(uint32_t)span);/* Holes are zero: only known descriptor values are retained. No pointers. */for(i=0;i<count;i++){unit=elem(entries[i].type);if(entries[i].type==1000138000){memcpy(p+32+entries[i].offset,src+entries[i].offset,entries[i].count);continue;}for(j=0;j<entries[i].count;j++)memcpy(p+32+entries[i].offset+j*entries[i].stride,src+entries[i].offset+j*entries[i].stride,(entries[i].type<=3||entries[i].type==10)?20:unit);}return 1;}
int pw_vk_wire_validate(uint32_t op,const void *v,size_t n){const unsigned char *p=v;uint32_t count,dc,flags;if(!v||n>MAX_PAYLOAD)return 0;switch(op){case PW_VK_PUSH_CONSTANTS:return n>=24&&(uint64_t)24+pw_vk_wire_u32(p+20)==n;case PW_VK_DRAW_INDEXED:return n==24;case PW_VK_BIND_PIPELINE:return n==16;case PW_VK_BIND_INDEX:return n==40&&pw_vk_wire_u32(p+32)<=1&&!pw_vk_wire_u32(p+36);case PW_VK_BIND_DESCRIPTORS:if(n<32||pw_vk_wire_u32(p+28))return 0;count=pw_vk_wire_u32(p+20);dc=pw_vk_wire_u32(p+24);return (uint64_t)32+(uint64_t)count*8+(uint64_t)dc*4==n;case PW_VK_BIND_VERTEX2:if(n<16)return 0;count=pw_vk_wire_u32(p+8);flags=pw_vk_wire_u32(p+12);return flags<=3&&(uint64_t)16+(uint64_t)count*32==n;case PW_VK_UPDATE_TEMPLATE:return n>=32&&!pw_vk_wire_u32(p+4)&&!pw_vk_wire_u32(p+28)&&(uint64_t)32+pw_vk_wire_u32(p+24)==n;default:return 0;}}
